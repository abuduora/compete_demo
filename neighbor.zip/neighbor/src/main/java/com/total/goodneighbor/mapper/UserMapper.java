package com.total.goodneighbor.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.total.goodneighbor.entity.userinformation;

public interface UserMapper extends BaseMapper<userinformation> {
}
