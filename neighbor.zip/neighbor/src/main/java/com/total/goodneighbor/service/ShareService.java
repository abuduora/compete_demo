package com.total.goodneighbor.service;

public interface ShareService {
}
