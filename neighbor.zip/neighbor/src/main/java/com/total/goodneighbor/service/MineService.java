package com.total.goodneighbor.service;

public interface MineService {
    public void setavater();
}
