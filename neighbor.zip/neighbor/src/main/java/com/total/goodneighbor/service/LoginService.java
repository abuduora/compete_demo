package com.total.goodneighbor.service;

public interface LoginService {
    public boolean saveemail(String email);
    public void saverealname(String realname);
    public void saveid(int id);
}
